//Jessie Zarate 8/15 Chapter 1 - Activity 2
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("mmh-hmm this is a tasty burger!");
		System.out.println("Pulp Fiction");
		System.out.println("Jules Winnfield");
		System.out.println("1994");

	}

}
