//Jessie Zarate 8/15 Chapter 1 - Activity 1

public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Oh won't you stay for the ride");
		System.out.println("Cuz oh the views will be nice");
		System.out.println("And the stories that we'll tell our friends");
		System.out.println("Will make 'em laugh until the party ends");
		System.out.println("Oh won't you stay for the ride");
		System.out.println("It's do or die");

	}

}
